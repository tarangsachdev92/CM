declare module '*.otf';
